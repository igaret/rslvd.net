# How to Access a Windows Service Behind CGNAT with rslvd.net

If your ISP uses CGNAT, normal port forwarding often will not work. Your router may let you create a port-forwarding rule, but traffic from the internet never reaches your Windows PC because the public IP address belongs to the ISP’s shared NAT gateway. rslvd.net solves this with an outbound tunnel. Your Windows computer connects out to rslvd.net, and rslvd.net gives you a public HTTPS URL that forwards back to your local service.

This tutorial walks through the Windows flow: creating a free rslvd.net account, creating a tunnel, downloading the Windows tunnel client, starting a local Windows test server, and publishing that local service through a public `rslvd.net` URL.

> Security note: only expose services you understand and trust. Do not expose Windows admin tools, router panels, NAS dashboards, cameras, or private apps unless they are patched, authenticated, and intended to be reachable from the internet.

## What you need

You need a Windows 10 or Windows 11 PC, PowerShell, a browser, and a local service to expose. For this demo, we use Python’s built-in web server on port `8000`. If Python is not installed, install it from the Microsoft Store or from `https://www.python.org/downloads/windows/`. In real use, replace port `8000` with the port used by your actual app, such as a local dev server on `3000`, a web server on `80`, or another TCP service.

## Step 1 — Create a free rslvd.net account

Open `https://rslvd.net/register` in your browser and create a free account. Enter your email, choose a password, accept the Terms of Service and Privacy Policy, then click **Create account — free**.

![rslvd.net registration page](public-screenshots/01-register-page.png)

After signup, you land in the dashboard. A free account includes one hostname and one tunnel, enough to test remote access from Windows.

![empty rslvd.net dashboard](public-screenshots/02-dashboard-empty.png)

## Step 2 — Create a hostname

On the **Hosts** tab, click **Add hostname**. Pick a short subdomain. For example, if you enter `my-windows-pc`, the hostname becomes:

```text
my-windows-pc.rslvd.net
```

![add hostname modal](public-screenshots/03-add-hostname-modal.png)

The hostname is useful for Dynamic DNS. For CGNAT remote access, the tunnel is the most important part because it works even when inbound port forwarding does not.

## Step 3 — Open the Tunnels tab

Click **Tunnels** in the dashboard. This is where you create a public URL that forwards to a local port on your Windows PC.

![empty tunnels tab](public-screenshots/04-tunnels-empty.png)

Click **New tunnel** or **Create tunnel**.

## Step 4 — Create a tunnel for your Windows service

Give the tunnel a name and choose the local port to expose. This demo uses port `8000` because we will run a small test web server there.

Example settings:

```text
Tunnel name: my-windows-demo
Port to expose: 8000
Protocol: TCP
```

![new tunnel modal](public-screenshots/05-new-tunnel-modal.png)

After creating the tunnel, it appears in the dashboard with a public URL like:

```text
https://my-windows-demo.rslvd.net
```

![tunnel dashboard](public-screenshots/06-tunnel-dashboard.png)

## Step 5 — Start a local Windows test server

Open PowerShell. Create a demo folder and a simple test page:

```powershell
mkdir C:\rslvd-demo
cd C:\rslvd-demo
'Hello from Windows behind CGNAT' | Out-File -Encoding utf8 index.html
```

Start a local web server on port `8000`:

```powershell
py -m http.server 8000
```

Leave this PowerShell window open. You should see output similar to:

```text
Serving HTTP on :: port 8000 (http://[::]:8000/) ...
```

Open another PowerShell window and test the local service:

```powershell
curl http://localhost:8000
```

You should see the test page content returned.

## Step 6 — Download the Windows tunnel client

Back in the rslvd.net dashboard, click **Connect** on your tunnel, then click the **Windows** tab. Download the Windows binary:

```text
rslvd-tunnel-windows-amd64.exe
```

The dashboard also shows the exact command to run. Keep the tunnel token private.

![Windows tunnel commands](public-screenshots/07-windows-connect-commands.png)

If Windows SmartScreen warns you about an unknown app, that means Windows does not yet recognize the downloaded binary’s publisher/reputation. Only continue if you intentionally downloaded it from `https://rslvd.net` and trust the source.

## Step 7 — Run the tunnel from PowerShell

Open PowerShell in the same folder where you downloaded the `.exe`, usually your Downloads folder:

```powershell
cd $env:USERPROFILE\Downloads
```

Run the command shown in your dashboard. It has this shape:

```powershell
.\rslvd-tunnel-windows-amd64.exe <YOUR_TUNNEL_TOKEN> 8000
```

A successful tunnel should show output similar to:

```text
rslvd tunnel starting...
local target: localhost:8000
public url: https://my-windows-demo.rslvd.net
status: connected
```

Keep this PowerShell window open. The tunnel runs while the command is running.

## Step 8 — Visit the public URL

Open the public URL shown in the rslvd.net dashboard:

```text
https://my-windows-demo.rslvd.net
```

You should see the page being served from your Windows PC:

```text
Hello from Windows behind CGNAT
```

That confirms the tunnel is working. Your Windows service is reachable through rslvd.net even if your ISP uses CGNAT, double NAT, or blocks normal inbound port forwarding.

## Optional — Run the tunnel more permanently

For testing, keeping PowerShell open is fine. For regular use, you may want to run the tunnel at login using Task Scheduler. Create a task that runs at user logon and starts a program with these values:

```text
Program/script: C:\Users\YOUR_USER\Downloads\rslvd-tunnel-windows-amd64.exe
Arguments: <YOUR_TUNNEL_TOKEN> 8000
Start in: C:\Users\YOUR_USER\Downloads
```

Use your real Windows username, token, and port. If your actual service starts after login, configure the task to delay for 30–60 seconds so the local service is ready before the tunnel starts.

## Optional — Dynamic DNS from Windows

If DDNS updates are enabled for your account or plan, the dashboard shows a Router DDNS URL. You can run it from PowerShell like this:

```powershell
curl "https://rslvd.net/api/update?key=<YOUR_UPDATE_KEY>&ip=auto"
```

DDNS is useful when you have a publicly reachable IP address. If you are behind CGNAT and need inbound access to a local service, use the tunnel flow above instead of relying on DDNS alone.

## Troubleshooting

If your public URL does not load, first confirm the local service works with `curl http://localhost:8000` on the Windows PC. Then confirm the `rslvd-tunnel-windows-amd64.exe` PowerShell window is still open and connected. Make sure the port in the tunnel command matches the local service port. If Windows Firewall prompts you, allow access for the local service if appropriate. If PowerShell says the file is not found, check that you are in the folder where the `.exe` was downloaded. If the tunnel was created with the wrong port, delete it in the rslvd.net dashboard and create a new one.
